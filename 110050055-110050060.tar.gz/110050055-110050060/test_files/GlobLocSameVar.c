int a;
main()
{
	int a;
	a = 3;
}
