main()
{
	int a = 3;
	int b = 2;
	int c = a ? a > b : a < b;
}
