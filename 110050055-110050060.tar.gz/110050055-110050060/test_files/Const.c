main()
{
	int a = 3;
	float b = 2.3;

	a = b + 3;
	b = a + 2.3;
	a = b + 4.3;
	b = a + 5;
}
