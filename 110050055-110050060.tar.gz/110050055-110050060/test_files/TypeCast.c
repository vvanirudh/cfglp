main()
{
	int a, b = 3, d, e, f, g;
	float c = 2.3;
	a = b / c;
}
