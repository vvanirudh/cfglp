int a;
int c;
main()
{
}
