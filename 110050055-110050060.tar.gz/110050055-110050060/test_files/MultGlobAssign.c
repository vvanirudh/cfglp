int a;
int b;
main()
{
	a = b;
	b = 3;
}
