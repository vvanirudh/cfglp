main()
{
	int a = 4;
	int b = 3;
	int c = 10;

	if (a != !b)
		a = a < b >= c;
	else
		b = a < b >= c;
}
