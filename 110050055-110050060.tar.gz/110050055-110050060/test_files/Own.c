main ()
{
	int a;
	int b;
	int c;

	a = 2;
	b = a;
	b = 4;
}
