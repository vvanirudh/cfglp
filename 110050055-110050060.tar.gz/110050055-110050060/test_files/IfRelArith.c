main()
{
	int a = 2, b = 4, c = 10, d = 3, e = 8, f = 7;

	if (a >= b + c / d < e - a != f)
		a += d * e / f <= b;
	else
		b = 1;
}
