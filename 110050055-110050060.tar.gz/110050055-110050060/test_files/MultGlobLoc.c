int a;
int b;
int c;
main()
{
	int a;
	int d;
	int e;
	int f;
	int g;
	int b;

	a = 3;
	c = 2;
	f = b;
	d = 4;
	d = a;
	a = d;
	a = b;
	g = d;
	e = a;
	e = 4;
	e = 4;
	d = e;
	d = a;
	e = a;
}
