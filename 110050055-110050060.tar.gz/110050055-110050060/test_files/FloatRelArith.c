main()
{
	float a = 2.3, b = 3.4, c;

	c = a * b >= a < b + b;
}
