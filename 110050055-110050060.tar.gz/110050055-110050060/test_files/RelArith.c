main()
{
	int a = 3;
	int b = 8, c;

	c = a >= b + a == b;
}
