int a;
main()
{
	int b;
	b = a;
	a = 3;
}
