main()
{
	int a = 2, b = 3, c = 4;

	a = -(c * b);
}
