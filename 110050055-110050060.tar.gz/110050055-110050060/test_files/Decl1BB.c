main ()
{
	int a;
}
