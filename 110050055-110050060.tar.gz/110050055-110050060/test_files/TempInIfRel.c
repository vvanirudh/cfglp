main()
{
	int a = 3;
	int b = 4;
	int c = 2;

	if (a > 2)
		c = a > b > c;
	else
		c = a > b > c;
}
