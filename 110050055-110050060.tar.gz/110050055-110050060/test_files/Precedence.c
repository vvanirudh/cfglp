main()
{
	int a = 2;
	int b = 4;
	int c = 3;
	int d = 5;

	if (a > (b == c) < d)
		a = 10;
	else
		a = 11;
}
