main()
{
	int a = 3;
	int b;
	b = a;
}
