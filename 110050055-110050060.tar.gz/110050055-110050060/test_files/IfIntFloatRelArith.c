main()
{
	int a = 2, b = 3, c = 4, d = 5;	
	float e = 2.3, f = 3.4, g = 4.5, h = 5.5;

	a = a + e / f * d;

	if (a != b <= d + g * h / e != 0)
		a++;
	else
		e++;
}
