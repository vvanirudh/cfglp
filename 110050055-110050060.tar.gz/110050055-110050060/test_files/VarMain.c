main()
{
	int Main = 5;
}
