int a;
main()
{
}
